/*Author: Sarvesh Sortee*/
#ifndef _HUSKY_RRT_H_
#define _HUSKY_RRT_H_

#include <ros/ros.h>
#include <costmap_2d/costmap_2d_ros.h>
#include <costmap_2d/costmap_2d.h>
#include <nav_core/base_global_planner.h>
#include <geometry_msgs/PoseStamped.h>
#include <angles/angles.h>
#include <base_local_planner/costmap_model.h>
#include <base_local_planner/world_model.h>
#include <nav_msgs/Path.h>

#include <iostream>
#include <set>
#include <string>
#include <vector>
/* #include <random/random_device.hpp>
#include <random/mersenne_twister.hpp>
#include <random/uniform_real_distribution.hpp>
#include <random/uniform_int_distribution.hpp> */
#include <boost/random/random_device.hpp>
#include <boost/random/mersenne_twister.hpp>
#include <boost/random/uniform_real_distribution.hpp>
#include <boost/random/uniform_int_distribution.hpp>
#include <octomap_msgs/conversions.h>

#include "rrt_planner/RRTNode.h"

namespace rrt_husky
{
    class RRTPlannerROS : public nav_core::BaseGlobalPlanner
    {

    private:
        ros::NodeHandle nh_;
        std::vector<bool> obstacle_map_;
        costmap_2d::Costmap2DROS *costmap_ros_;
        costmap_2d::Costmap2D *costmap_;
        octomap::OcTree *octree_;
        octomap::OcTree *inflated_octree_;
        ros::Publisher octomap_pub_;

        std::vector<octomap::point3d> inflator_;

        int max_iter_;
        int current_iter_;
        int max_control_;
        int goal_sample_rate_;
        int use_octomap_;

        base_local_planner::WorldModel *world_model_;
        bool initialized_;

        float goal_radius_;    //goal region
        float expand_dis_;     //step size
        float step_collision_; //Size of the sub-step used for collision checking
        float path_resolution_;
        //float robot_inflation_;
        float octomap_inflation_;
        float octomap_resolution_;

        float origin_x_;
        float origin_y_;
        float origin_yaw_;
        float origin_v_;
        float origin_phi_;

        float goal_x_;
        float goal_y_;
        float goal_yaw_;
        float goal_v_;
        float goal_phi_;

        ros::Subscriber octomap_sub_;

        unsigned int map_width_cells_;
        unsigned int map_height_cells_;

        std::vector<rrt_husky::RRTNode> node_list_;

        ros::Publisher plan_pub_;
        //boost::mutex mutex_;

    public:
        RRTPlannerROS();
        RRTPlannerROS(std::string name,
                      costmap_2d::Costmap2DROS *costmap_ros);

        void initialize(std::string name,
                        costmap_2d::Costmap2DROS *costmap_ros);
        bool makePlan(const geometry_msgs::PoseStamped &start,
                      const geometry_msgs::PoseStamped &goal,
                      std::vector<geometry_msgs::PoseStamped> &plan);

        std::vector<bool> getObstacleMap()
        {
            return obstacle_map_;
        }
        /* std::vector<rrt_husky::RRTNode> getNodeTree()
        {
            return node_list_;
        } */
        std::pair<float, float> getRandomPoint();
        float getRandomYaw();
        std::pair<float, float> getRandomControl();

        int getNearestNode(std::pair<float, float> location, float yaw);
        void addNodeToList(rrt_husky::RRTNode node)
        {
            node_list_.push_back(node);
        }
        float calcDistance(std::pair<float, float> start_loc, float start_yaw, std::pair<float, float> end_loc, float end_yaw);
        float calcDistance(int start_node, int end_node);
        float calcEuclideanDistance(std::pair<float, float> start_loc, std::pair<float, float> end_loc);

        bool steerTowardsPoint(int nearest_node, std::pair<float, float> random_point, float random_yaw);

        bool goalReached(int node);

        bool isSafe(std::pair<float, float> start_loc, std::pair<float, float> end_loc);

        std::vector<geometry_msgs::PoseStamped> buildPlan(int goal_index,
                                                          const geometry_msgs::PoseStamped &start,
                                                          const geometry_msgs::PoseStamped &goal);

        int findPath(const geometry_msgs::PoseStamped &start,
                     const geometry_msgs::PoseStamped &goal);
        float normalizeAngle(float x);

        void publishPlan(std::vector<geometry_msgs::PoseStamped> &plan);

        void octomapCallback(const octomap_msgs::OctomapConstPtr &octomap);

        bool hitsObstacle(std::pair<float, float> start_loc);

        void createOctomapInflator(float &radius);
        void createOctomapInflator(float &radius, float &height);

        void inflateOctomap(octomap::OcTree *&map);
    };
} // namespace rrt_husky

#endif