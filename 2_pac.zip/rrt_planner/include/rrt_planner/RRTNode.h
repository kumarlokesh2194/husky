/*Author: Sarvesh Sortee*/
#ifndef _HUSKY_RRT_NODE_H_
#define _HUSKY_RRT_NODE_H_

#include <cmath>
#include <utility>

namespace rrt_husky
{
    class RRTNode
    {
        
        
    private:
        float x_;
        float y_;
        float yaw_; //in radians
        float v_;
        float phi_;

        float index_;
        float parent_;

    public:
        RRTNode();
        RRTNode(float x, float y, float yaw, float v, float phi, int index, int parent);
        ~RRTNode(){

        }

        void setLocation(float x, float y);
        void setControl(float v, float phi);
        void setYaw(float yaw);
        void setIndex(int index);
        void setParent(int parent);
        std::pair<float, float> getLocation();
        float getYaw();
        std::pair<float,float> getControl();
        int getIndex();
        int getParent();

        
    };
} // namespace rrt_husky
#endif